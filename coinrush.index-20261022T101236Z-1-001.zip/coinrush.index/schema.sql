CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(80) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    virtual_coins BIGINT NOT NULL DEFAULT 100
        CHECK (virtual_coins >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS coin_transactions (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id),
    amount BIGINT NOT NULL,
    transaction_type VARCHAR(30) NOT NULL
        CHECK (transaction_type IN ('welcome', 'game_reward', 'adjustment')),
    description TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS game_claims (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id),
    game_id INTEGER NOT NULL CHECK (game_id BETWEEN 1 AND 4),
    claimed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_transactions_user
ON coin_transactions(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_game_claims_user
ON game_claims(user_id, game_id, claimed_at DESC);

CREATE OR REPLACE FUNCTION record_welcome_coins()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO coin_transactions
      (user_id, amount, transaction_type, description)
    VALUES
      (NEW.id, 100, 'welcome', 'Starting virtual demo coins');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS users_welcome_coins ON users;

CREATE TRIGGER users_welcome_coins
AFTER INSERT ON users
FOR EACH ROW EXECUTE FUNCTION record_welcome_coins();